@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('content')
<div class="bg-white p-6 rounded shadow">
    <h1 class="text-2xl font-semibold mb-4">Admin Dashboard</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <a href="{{ route('trips.index') }}" class="block p-4 bg-blue-100 hover:bg-blue-200 rounded text-center">Manage Trips</a>
        <a href="{{ route('trip-requests.index') }}" class="block p-4 bg-green-100 hover:bg-green-200 rounded text-center">View Trip Requests</a>
        <a href="{{ route('recommendations.index') }}" class="block p-4 bg-yellow-100 hover:bg-yellow-200 rounded text-center">View Recommendations</a>
    </div>
</div>
<div class="stats">
    <div class="stat-box">
        <h3 class="count" data-count="{{ $tripsCount }}">0</h3>
        <p>Trips</p>
    </div>
    <div class="stat-box">
        <h3 class="count" data-count="{{ $requestsCount }}">0</h3>
        <p>Requests</p>
    </div>
</div>

<script>
    document.querySelectorAll('.count').forEach(el => {
        let end = +el.dataset.count;
        let start = 0;
        let step = Math.ceil(end / 100);
        let interval = setInterval(() => {
            start += step;
            if (start >= end) {
                el.innerText = end;
                clearInterval(interval);
            } else {
                el.innerText = start;
            }
        }, 20);
    });
</script>
<div class="bg-white rounded-lg shadow p-4">
    <h2 class="text-xl font-bold mb-2">Dashboard Stats</h2>
    <canvas id="statsChart" height="100"></canvas>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    fetch("{{ route('dashboard.stats') }}")
        .then(res => res.json())
        .then(data => {
            const ctx = document.getElementById('statsChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Users', 'Trips', 'Reviews'],
                    datasets: [{
                        label: 'Count',
                        data: [data.users, data.trips, data.reviews],
                        backgroundColor: ['#4F46E5', '#10B981', '#F59E0B'],
                        borderRadius: 10
                    }]
                }
            });
        });
</script>
@endpush
@endsection