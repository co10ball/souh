@extends('layouts.app')

@section('title', 'الرحلات')

@section('content')
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5d3d3;
        margin: 0;
        padding: 20px;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .trip {
        background-color: #f9a0a0;
        border: 1px solid #e6a4a4;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 20px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .trip h3 {
        margin: 0 0 10px;
    }

    .trip p {
        margin: 5px 0;
    }

    .trip strong {
        display: block;
        margin-top: 10px;
        font-size: 1.2em;
    }
</style>

<h2>جميع الرحلات المتاحة</h2>

@foreach($trips as $trip)
    <div class="trip">
        <h3>{{ $trip->title }}</h3>
        <p>{{ $trip->description }}</p>
        <strong>السعر: ${{ $trip->price }}</strong>
        <p>الموقع: {{ $trip->location }}</p>
    </div>
@endforeach
@endsection