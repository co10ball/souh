<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="سواح - دليلك للسياحة والرحلات. اكتشف أفضل الوجهات السياحية بأسعار تنافسية." />
    <meta name="keywords" content="سياحة, رحلات, سفر, جولات, عروض" />
    <title>سواح - دليلك للسياحة والرحلات</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Cairo', sans-serif; scroll-behavior: smooth; }
        .nav-link {
            @apply text-gray-800 hover:text-blue-600 transition-colors font-medium relative;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            right: 0;
            bottom: -4px;
            width: 0%;
            height: 2px;
            background-color: #3b82f6; /* لون أزرق جديد */
            transition: all 0.3s ease-in-out;
        }
        .nav-link:hover::after {
            width: 100%;
        }
        .card-hover:hover {
            transform: scale(1.02);
            transition: all 0.3s ease-in-out;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .floating {
            animation: float 6s ease-in-out infinite;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-800">

    <!-- Navigation -->
    <nav class="bg-white shadow-xl sticky top-0 z-50 border-b border-blue-200">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4 space-x-reverse">
                    <div class="text-3xl font-extrabold text-blue-700 flex items-center gap-2">
                        <i class="fas fa-plane-departure text-4xl"></i>
                        <span>سواح</span>
                    </div>
                    <span class="text-gray-600 text-sm">دليلك للسياحة والرحلات</span>
                </div>
                <div class="hidden md:flex items-center space-x-6 space-x-reverse text-base font-medium">
                    <a href="#home" class="nav-link">الرئيسية</a>
                    <a href="#trips" class="nav-link">الرحلات</a>
                    <a href="#features" class="nav-link">مميزاتنا</a>
                    <a href="#recommendations" class="nav-link">التوصيات</a>
                    <a href="#reviews" class="nav-link">التقييمات</a>
                    <a href="#partners" class="nav-link">شركاؤنا</a>
                    <a href="#faq" class="nav-link">الأسئلة الشائعة</a>
                    <a href="#contact" class="nav-link">اتصل بنا</a>
                </div>
                <div class="flex items-center space-x-4 space-x-reverse">
                    <a href="{{ route('booking') }}" class="bg-blue-400 text-white px-5 py-2 rounded-full hover:bg-blue-300 transition-all shadow font-semibold text-sm md:text-base">
                        <i class="fas fa-calendar-check ml-2"></i>
                        احجز الآن
                    </a>
                    <a href="{{ route('login') }}" class="bg-blue-600 text-white px-5 py-2 rounded-full hover:bg-blue-700 transition font-semibold text-sm md:text-base">
                        <i class="fas fa-sign-in-alt ml-2"></i>
                        تسجيل الدخول
                    </a>
                    <a href="{{ route('register') }}" class="border border-blue-600 text-blue-600 px-5 py-2 rounded-full hover:bg-blue-50 transition font-semibold text-sm md:text-base">
                        <i class="fas fa-user-plus ml-2"></i>
                        إنشاء حساب
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-bg min-h-screen flex items-center relative" style="background-color: #e0f2fe;">
        <div class="container mx-auto px-4 text-center text-gray-800 relative z-10">
            <div class="floating">
                <h1 class="text-5xl md:text-7xl font-bold mb-6">
                    اكتشف العالم مع
                    <span class="text-blue-500">سواح</span>
                </h1>
                <p class="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
                    رحلات استثنائية، تقييمات حقيقية، وأسعار تنافسية لأجمل الوجهات السياحية حول العالم
                </p>
            </div>
            <div class="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-4 md:space-x-reverse mb-12">
                <button class="bg-blue-500 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-blue-400 transition-all transform hover:scale-105 shadow-xl">
                    <i class="fas fa-search ml-2"></i>
                    استكشف الرحلات
                </button>
                <button class="glass-effect text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:bg-opacity-20 transition-all">
                    <i class="fas fa-play-circle ml-2"></i>
                    شاهد الفيديو
                </button>
            </div>
            <!-- Stats -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
                <div class="text-center">
                    <div class="text-3xl md:text-4xl font-bold text-blue-500 mb-2">500+</div>
                    <div class="text-sm md:text-base">وجهة سياحية</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl md:text-4xl font-bold text-blue-500 mb-2">10k+</div>
                    <div class="text-sm md:text-base">عميل سعيد</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl md:text-4xl font-bold text-blue-500 mb-2">25+</div>
                    <div class="text-sm md:text-base">دولة</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl md:text-4xl font-bold text-blue-500 mb-2">4.9★</div>
                    <div class="text-sm md:text-base">تقييم العملاء</div>
                </div>
            </div>
        </div>
        <!-- Floating Elements -->
        <div class="absolute top-20 right-10 text-gray-800 text-6xl opacity-20 floating" style="animation-delay: -2s;">
            <i class="fas fa-mountain" aria-hidden="true"></i>
        </div>
        <div class="absolute bottom-20 left-10 text-gray-800 text-4xl opacity-20 floating" style="animation-delay: -4s;">
            <i class="fas fa-ship" aria-hidden="true"></i>
        </div>
        <div class="absolute top-1/2 left-20 text-gray-800 text-5xl opacity-20 floating" style="animation-delay: -1s;">
            <i class="fas fa-umbrella-beach" aria-hidden="true"></i>
        </div>
    </section>

    <!-- Featured Trips -->
    <section id="trips" class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">الرحلات المميزة</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">اختر من مجموعة متنوعة من الرحلات المصممة خصيصاً لتناسب جميع الأذواق والميزانيات</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Trip Card 1 -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden card-hover">
                    <div class="relative">
                        <div class="h-64 bg-gradient-to-br from-blue-300 to-blue-500"></div>
                        <div class="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                            <i class="fas fa-camera text-white text-4xl"></i>
                        </div>
                        <div class="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                            مميزة
                        </div>
                        <div class="absolute bottom-4 left-4 bg-white bg-opacity-90 px-3 py-1 rounded-full">
                            <div class="flex items-center text-yellow-500">
                                <i class="fas fa-star"></i>
                                <span class="mr-1 text-gray-800 font-bold">4.8</span>
                            </div>
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-2">رحلة إلى جزر المالديف</h3>
                        <p class="text-gray-600 mb-4">استمتع بأجمل الشواطئ والمياه الفيروزية في جنة على الأرض</p>
                        <div class="flex items-center justify-between">
                            <div class="text-2xl font-bold text-blue-600">2,500 ريال</div>
                            <button class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition-colors">
                                عرض التفاصيل
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Trip Card 2 -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden card-hover">
                    <div class="relative">
                        <div class="h-64 bg-gradient-to-br from-green-300 to-green-500"></div>
                        <div class="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                            <i class="fas fa-mountain text-white text-4xl"></i>
                        </div>
                        <div class="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                            جديدة
                        </div>
                        <div class="absolute bottom-4 left-4 bg-white bg-opacity-90 px-3 py-1 rounded-full">
                            <div class="flex items-center text-yellow-500">
                                <i class="fas fa-star"></i>
                                <span class="mr-1 text-gray-800 font-bold">4.6</span>
                            </div>
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-2">مغامرة في جبال الألب</h3>
                        <p class="text-gray-600 mb-4">تسلق أعلى القمم واستمتع بالطبيعة الخلابة والهواء النقي</p>
                        <div class="flex items-center justify-between">
                            <div class="text-2xl font-bold text-blue-600">3,200 ريال</div>
                            <button class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition-colors">
                                عرض التفاصيل
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Trip Card 3 -->
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden card-hover">
                    <div class="relative">
                        <div class="h-64 bg-gradient-to-br from-orange-300 to-orange-500"></div>
                        <div class="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                            <i class="fas fa-umbrella-beach text-white text-4xl"></i>
                        </div>
                        <div class="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                            الأكثر طلباً
                        </div>
                        <div class="absolute bottom-4 left-4 bg-white bg-opacity-90 px-3 py-1 rounded-full">
                            <div class="flex items-center text-yellow-500">
                                <i class="fas fa-star"></i>
                                <span class="mr-1 text-gray-800 font-bold">4.9</span>
                            </div>
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-2">استرخاء في بالي</h3>
                        <p class="text-gray-600 mb-4">شواطئ ساحرة، ثقافة غنية، ومنتجعات فاخرة في جزيرة الآلهة</p>
                        <div class="flex items-center justify-between">
                            <div class="text-2xl font-bold text-blue-600">1,800 ريال</div>
                            <button class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition-colors">
                                عرض التفاصيل
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-12">
                <button class="bg-gradient-to-r from-blue-600 to-blue-400 text-white px-8 py-4 rounded-full font-bold text-lg hover:shadow-xl transition-all transform hover:scale-105">
                    <i class="fas fa-eye ml-2"></i>
                    عرض جميع الرحلات
                </button>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimonials" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">آراء عملائنا</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">إليك بعض الآراء من عملائنا السعداء الذين استمتعوا برحلاتنا.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <p class="text-gray-600 mb-4">"كانت رحلتي إلى جزر المالديف تجربة لا تُنسى! كل شيء كان رائعًا."</p>
                    <h4 class="font-bold text-gray-800">أحمد العلي</h4>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <p class="text-gray-600 mb-4">"خدمة العملاء كانت ممتازة، وساعدوني في اختيار الرحلة المثالية."</p>
                    <h4 class="font-bold text-gray-800">سارة محمد</h4>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <p class="text-gray-600 mb-4">"رحلة جبال الألب كانت مذهلة! سأعود بالتأكيد مرة أخرى."</p>
                    <h4 class="font-bold text-gray-800">علي حسن</h4>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Form Section -->
    <section id="contact" class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">اتصل بنا</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">إذا كان لديك أي استفسارات، لا تتردد في التواصل معنا.</p>
            </div>
            <form action="#" method="POST" class="max-w-lg mx-auto">
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">الاسم</label>
                    <input type="text" name="name" id="name" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200" />
                </div>
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-gray-700">البريد الإلكتروني</label>
                    <input type="email" name="email" id="email" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200" />
                </div>
                <div class="mb-4">
                    <label for="message" class="block text-sm font-medium text-gray-700">الرسالة</label>
                    <textarea name="message" id="message" rows="4" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200"></textarea>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors">إرسال</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-10">
        <div class="container mx-auto px-4 text-center">
            <p class="mb-4">© 2023 سواح. جميع الحقوق محفوظة.</p>
            <div class="flex justify-center space-x-4">
                <a href="#" class="hover:text-blue-300"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="hover:text-blue-300"><i class="fab fa-twitter"></i></a>
                <a href="#" class="hover:text-blue-300"><i class="fab fa-instagram"></i></a>
                <a href="#" class="hover:text-blue-300"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </footer>

</body>
</html>
