
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #eb9696;
        margin: 0;
        padding: 20px;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    form {
        max-width: 600px;
        margin: auto;
        padding: 20px;
        border: 1px solid #9ec5c6;
        border-radius: 8px;
        background-color: #7cc6f7;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    select, textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-bottom: 15px;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }

    button:hover {
        background-color: #45a049;
    }
</style>

<h2>طلب انضمام إلى رحلة</h2>

<form action="{{ route('trip.request.store') }}" method="POST">
    @csrf
    <label>اختر الرحلة:</label>
    <select name="trip_id" required>
        @foreach($trips as $trip)
            <option value="{{ $trip->id }}">{{ $trip->title }}</option>
        @endforeach
    </select>

    <label>رسالة:</label>
    <textarea name="message" required></textarea>

    <button type="submit">إرسال الطلب</button>
</form>
