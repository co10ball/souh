@extends('layouts.app')

@section('title', 'Live Chat')

@section('content')
<style>
    body {
        background-color: #f3f4f6; /* لون خلفية الصفحة */
    }
    .chat-container {
        padding: 1.5rem; /* حشوة الحاوية */
    }
    .chat-title {
        font-size: 1.5rem; /* حجم عنوان الدردشة */
        font-weight: bold; /* جعل العنوان بخط عريض */
        margin-bottom: 1rem; /* مسافة أسفل العنوان */
        text-align: center; /* محاذاة العنوان إلى الوسط */
    }
    .message-box {
        background-color: #ffffff; /* لون خلفية صندوق الرسائل */
        height: 24rem; /* ارتفاع صندوق الرسائل */
        overflow-y: scroll; /* تمكين التمرير العمودي */
        padding: 1rem; /* حشوة صندوق الرسائل */
        border-radius: 0.5rem; /* زوايا صندوق الرسائل */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* ظل صندوق الرسائل */
        margin-bottom: 1rem; /* مسافة أسفل صندوق الرسائل */
    }
    .message {
        margin-bottom: 0.5rem; /* مسافة أسفل كل رسالة */
    }
    .message-user {
        color: #3b82f6; /* لون اسم المستخدم */
        font-weight: bold; /* جعل اسم المستخدم بخط عريض */
    }
    .message-time {
        color: #6b7280; /* لون وقت الرسالة */
        font-size: 0.75rem; /* حجم خط وقت الرسالة */
    }
    .input-container {
        display: flex; /* استخدام flexbox لتنسيق المدخلات */
    }
    .input-message {
        flex: 1; /* جعل المدخلات تأخذ المساحة المتاحة */
        border-radius: 0.375rem 0 0 0.375rem; /* زوايا المدخل */
        border: 1px solid #d1d5db; /* لون حدود المدخل */
        padding: 0.5rem; /* حشوة المدخل */
    }
    .input-message:focus {
        border-color: #3b82f6; /* لون الحدود عند التركيز */
        outline: none; /* إزالة الإطار الافتراضي */
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5); /* تأثير الظل عند التركيز */
    }
    .send-button {
        background-color: #3b82f6; /* لون خلفية الزر */
        color: #ffffff; /* لون نص الزر */
        padding: 0.5rem 1rem; /* حشوة الزر */
        border-radius: 0 0.375rem 0.375rem 0; /* زوايا الزر */
        border: none; /* إزالة الحدود */
        cursor: pointer; /* تغيير المؤشر عند التمرير فوق الزر */
    }
    .send-button:hover {
        background-color: #2563eb; /* لون الزر عند التمرير */
    }
</style>

<div class="chat-container">
    <h1 class="chat-title">Live Chat</h1>

    <div class="message-box">
        @foreach ($messages as $msg)
            <div class="message">
                <strong class="message-user">{{ $msg->user->name }}</strong>:
                <span>{{ $msg->message }}</span>
                <small class="message-time">{{ $msg->created_at->diffForHumans() }}</small>
            </div>
        @endforeach
    </div>

    <form method="POST" action="{{ route('chat.send') }}">
        @csrf
        <div class="input-container">
            <input type="text" name="message" class="input-message" placeholder="Type a message..." required>
            <button type="submit" class="send-button">Send</button>
        </div>
    </form>
</div>
@endsection