
<style>
    body {
        background-color: #f3f4f6; /* لون خلفية الصفحة */
    }
    .container {
        background-color: #ffffff; /* لون خلفية النموذج */
        padding: 2rem;
        border-radius: 0.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        max-width: 400px; /* عرض النموذج */
        margin: auto; /* محاذاة النموذج إلى الوسط */
        margin-top: 100px; /* مسافة أعلى النموذج */
    }
    h2 {
        text-align: center; /* محاذاة العنوان إلى الوسط */
        margin-bottom: 1.5rem; /* مسافة أسفل العنوان */
    }
    .form-control {
        width: 100%; /* عرض المدخل */
        padding: 0.5rem; /* حشوة المدخل */
        border: 1px solid #d1d5db; /* لون حدود المدخل */
        border-radius: 0.375rem; /* زوايا المدخل */
        transition: border-color 0.2s; /* تأثير الانتقال */
        margin-bottom: 1rem; /* مسافة أسفل المدخل */
    }
    .form-control:focus {
        border-color: #3b82f6; /* لون الحدود عند التركيز */
        outline: none; /* إزالة الإطار الافتراضي */
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5); /* تأثير الظل عند التركيز */
    }
    .btn-primary {
        background-color: #3b82f6; /* لون خلفية الزر */
        color: #ffffff; /* لون نص الزر */
        padding: 0.5rem; /* حشوة الزر */
        border-radius: 0.375rem; /* زوايا الزر */
        width: 100%; /* عرض الزر */
        transition: background-color 0.2s; /* تأثير الانتقال */
    }
    .btn-primary:hover {
        background-color: #2563eb; /* لون الزر عند التمرير */
    }
</style>

<div class="container">
    <h2>أدخل رمز التحقق الثنائي</h2>
    <form method="POST" action="{{ route('2fa.verify') }}">
        
        <input type="text" name="code" class="form-control" placeholder="أدخل الرمز المكون من 6 أرقام" required>
        <button type="submit" class="btn btn-primary mt-2">تحقق</button>
    </form>
</div>
