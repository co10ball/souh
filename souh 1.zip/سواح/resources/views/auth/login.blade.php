<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #8aacf0; /* لون خلفية الصفحة */
        }
        .form-container {
            background-color: #ffffff; /* لون خلفية النموذج */
            padding: 2rem;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 24rem; /* عرض النموذج */
        }
        .form-title {
            font-size: 1.5rem; /* حجم عنوان النموذج */
            font-weight: bold;
            margin-bottom: 1.5rem; /* مسافة أسفل العنوان */
            text-align: center; /* محاذاة العنوان إلى الوسط */
        }
        .error-message {
            color: #dc2626; /* لون الرسالة الخطأ */
            margin-bottom: 1rem; /* مسافة أسفل الرسالة الخطأ */
        }
        .form-label {
            display: block; /* عرض التسمية ككتلة */
            margin-bottom: 0.5rem; /* مسافة أسفل التسمية */
            color: #374151; /* لون التسمية */
        }
        .form-input {
            width: 100%; /* عرض المدخل */
            padding: 0.5rem; /* حشوة المدخل */
            border: 1px solid #d1d5db; /* لون حدود المدخل */
            border-radius: 0.375rem; /* زوايا المدخل */
            transition: border-color 0.2s; /* تأثير الانتقال */
        }
        .form-input:focus {
            border-color: #3b82f6; /* لون الحدود عند التركيز */
            outline: none; /* إزالة الإطار الافتراضي */
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5); /* تأثير الظل عند التركيز */
        }
        .submit-button {
            width: 100%; /* عرض الزر */
            background-color: #3b82f6; /* لون خلفية الزر */
            color: #ffffff; /* لون نص الزر */
            padding: 0.5rem; /* حشوة الزر */
            border-radius: 0.375rem; /* زوايا الزر */
            transition: background-color 0.2s; /* تأثير الانتقال */
        }
        .submit-button:hover {
            background-color: #2563eb; /* لون الزر عند التمرير */
        }
        .register-link {
            margin-top: 1rem; /* مسافة أعلى الرابط */
            text-align: center; /* محاذاة الرابط إلى الوسط */
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">
    <div class="form-container">
        <h2 class="form-title">تسجيل الدخول</h2>
        <form action="{{ route('auth.login') }}" method="POST">
            
            <div class="mb-4">
                <label for="email" class="form-label">البريد الإلكتروني</label>
                <input type="email" name="email" id="email" required class="form-input" />
            </div>
            <div class="mb-4">
                <label for="password" class="form-label">كلمة المرور</label>
                <input type="password" name="password" id="password" required class="form-input" />
            </div>
            <button type="submit" class="submit-button">تسجيل الدخول</button>
        </form>
        <p class="register-link">
            ليس لديك حساب؟ <a href="{{ route('auth.register.form') }}" class="text-blue-600">إنشاء حساب</a>
        </p>
    </div>
</body>
</html>
