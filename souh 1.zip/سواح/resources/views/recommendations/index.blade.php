@extends('layouts.app')

@section('title', 'Recommendations')

@section('content')
<div class="p-6">
    <h1 class="text-2xl font-bold mb-4">Recommended Trips For You</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach ($recommendedTrips as $trip)
            <div class="bg-white shadow rounded-lg p-4">
                <h2 class="text-lg font-semibold">{{ $trip->title }}</h2>
                <p class="text-gray-600">{{ Str::limit($trip->description, 100) }}</p>
                <p class="mt-2 text-sm text-yellow-600">Avg Rating: {{ number_format($trip->reviews_avg_rating, 1) }}/5</p>
                <a href="{{ route('trips.show', $trip->id) }}" class="text-blue-500 hover:underline mt-2 inline-block">View Trip</a>
            </div>
        @endforeach
    </div>
</div>
@endsection