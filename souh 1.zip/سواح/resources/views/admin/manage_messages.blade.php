@extends('layouts.app')

@section('title', 'إدارة الرسائل')

@section('content')
<style>
    body {
        background-color: #f3f4f6; /* لون خلفية الصفحة */
    }
    h2 {
        text-align: center; /* محاذاة العنوان إلى الوسط */
        margin-bottom: 20px; /* مسافة أسفل العنوان */
    }
    .message-container {
        background-color: #ffffff; /* لون خلفية الرسالة */
        border-radius: 0.5rem; /* زوايا الرسالة */
        padding: 1rem; /* حشوة الرسالة */
        margin-bottom: 20px; /* مسافة أسفل الرسالة */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* ظل الرسالة */
    }
    .message-container p {
        margin: 5px 0; /* مسافة بين الفقرات */
    }
    .message-user {
        font-weight: bold; /* جعل اسم المستخدم بخط عريض */
    }
    .message-type {
        color: #6b7280; /* لون نوع الرسالة */
    }
</style>

<h2>جميع الرسائل</h2>

@foreach($messages as $msg)
    <div class="message-container">
        <p class="message-user">المستخدم: {{ $msg->user->name }}</p>
        <p class="message-content"><strong>المحتوى:</strong> {{ $msg->content }}</p>
        <p class="message-type"><strong>النوع:</strong> {{ $msg->type }}</p>
    </div>
@endforeach
@endsection