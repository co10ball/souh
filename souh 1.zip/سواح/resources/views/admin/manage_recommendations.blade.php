@extends('layouts.app')

@section('title', 'إدارة التوصيات')

@section('content')
<style>
    body {
        background-color: #f3f4f6; /* لون خلفية الصفحة */
    }
    h2 {
        text-align: center; /* محاذاة العنوان إلى الوسط */
        margin-bottom: 20px; /* مسافة أسفل العنوان */
    }
    .recommendation-container {
        background-color: #ffffff; /* لون خلفية التوصية */
        border-radius: 0.5rem; /* زوايا التوصية */
        padding: 1rem; /* حشوة التوصية */
        margin-bottom: 20px; /* مسافة أسفل التوصية */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* ظل التوصية */
    }
    .recommendation-container p {
        margin: 5px 0; /* مسافة بين الفقرات */
    }
    .recommendation-user {
        font-weight: bold; /* جعل اسم المستخدم بخط عريض */
    }
</style>

<h2>جميع التوصيات</h2>

@foreach($recommendations as $rec)
    <div class="recommendation-container">
        <p class="recommendation-user">المستخدم: {{ $rec->user->name }}</p>
        <p class="recommendation-content"><strong>المحتوى:</strong> {{ $rec->content }}</p>
    </div>
@endforeach
@endsection