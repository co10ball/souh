
<style>
    body {
        background-color: #f3f4f6; /* لون خلفية الصفحة */
    }
    h2 {
        text-align: center; /* محاذاة العنوان إلى الوسط */
        margin-bottom: 20px; /* مسافة أسفل العنوان */
    }
    .trip-container {
        background-color: #ffffff; /* لون خلفية الرحلة */
        border-radius: 0.5rem; /* زوايا الرحلة */
        padding: 1rem; /* حشوة الرحلة */
        margin-bottom: 20px; /* مسافة أسفل الرحلة */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* ظل الرحلة */
    }
    .trip-container h4 {
        margin: 0; /* إزالة المسافة الافتراضية */
        font-size: 1.25rem; /* حجم عنوان الرحلة */
    }
    .trip-container p {
        margin: 5px 0; /* مسافة بين الفقرات */
    }
    .trip-price {
        font-weight: bold; /* جعل السعر بخط عريض */
        color: #3b82f6; /* لون السعر */
    }
</style>

<h2>جميع الرحلات</h2>


    <div class="trip-container">
        <h4>{{ $trip->title }}</h4>
        <p>{{ $trip->description }}</p>
        <strong class="trip-price">${{ $trip->price }}</strong>
    </div>
