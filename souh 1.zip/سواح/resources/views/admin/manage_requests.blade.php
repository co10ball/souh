
<style>
    body {
        background-color: #f3f4f6; /* لون خلفية الصفحة */
    }
    h2 {
        text-align: center; /* محاذاة العنوان إلى الوسط */
        margin-bottom: 20px; /* مسافة أسفل العنوان */
    }
    .request-container {
        background-color: #ffffff; /* لون خلفية الطلب */
        border-radius: 0.5rem; /* زوايا الطلب */
        padding: 1rem; /* حشوة الطلب */
        margin-bottom: 20px; /* مسافة أسفل الطلب */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* ظل الطلب */
    }
    .request-container p {
        margin: 5px 0; /* مسافة بين الفقرات */
    }
    .request-user {
        font-weight: bold; /* جعل اسم المستخدم بخط عريض */
    }
    .request-status {
        color: #3b82f6; /* لون الحالة */
        font-weight: bold; /* جعل الحالة بخط عريض */
    }
</style>

<h2>جميع طلبات الرحلات</h2>


    <div class="request-container">
        <p class="request-user"><strong>المستخدم:</strong> {{ $req->user->name }}</p>
        <p><strong>الرحلة:</strong> {{ $req->trip->title }}</p>
        <p><strong>الرسالة:</strong> {{ $req->message }}</p>
        <p class="request-status"><strong>الحالة:</strong> {{ $req->status }}</p>
    </div>
