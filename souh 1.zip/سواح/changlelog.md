# Changelog

## [1.0.0] - 2025-08-02
- Initial release of the Souh tourism project.
- Added login, registration, and dashboard.
- Integrated roles (admin, user).
- Added trip request & suggestions system.