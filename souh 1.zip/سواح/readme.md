# Souh - Tourism Evaluation Platform

Souh is a Laravel-based application to help users browse and rate tourist trips, and allow admins to manage content.

## Installation

1. Clone the repository:
```bash
git clone https://github.com/co10ball/-2.git
cd souh
# Souh - Travel Evaluation Platform

## Features
- Trip listing and requests
- Admin panel for managing trips
- Messaging and recommendations
- Role-based access control
- Notifications, form validation, and logging

## Tech Stack
- Laravel 10
- Blade Templating
- MySQL
- GitHub Actions CI

## Setup
```bash
git clone https://github.com/co10ball/-2.git
cd souh
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
npm install && npm run dev
php artisan serve