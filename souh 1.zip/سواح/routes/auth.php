<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\Auth\EmailVerificationPromptController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\RegisteredUser Controller;
use App\Http\Controllers\Auth\VerifyEmailController;
use Illuminate\Support\Facades\Route;

// مسارات المستخدمين الضيوف (غير المسجلين)
Route::middleware('guest')->group(function () {
  ئ  Route::get('register', [RegisteredUserController::class, 'create'])
        ->name('register'); // عرض نموذج التسجيل        
    Route::get('login', [AuthenticatedSessionController::class, 'create'])
        ->name('login'); // عرض نموذج تسجيل الدخول

    Route::post('login', [AuthenticatedSessionController::class, 'store']); // تخزين بيانات تسجيل الدخول

    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])
        ->name('password.request'); // عرض نموذج استعادة كلمة المرور

    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])
        ->name('password.email'); // إرسال رابط استعادة كلمة المرور

    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])
        ->name('password.reset'); // عرض نموذج إعادة تعيين كلمة المرور

    Route::post('reset-password', [NewPasswordController::class, 'store'])
        ->name('password.store'); // تخزين كلمة المرور الجديدة
});

// مسارات المستخدمين المسجلين
Route::middleware('auth')->group(function () {
    Route::get('verify-email', EmailVerificationPromptController::class)
        ->name('verification.notice'); // عرض إشعار التحقق من البريد الإلكتروني

    Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)
        ->middleware(['signed', 'throttle:6,1']) // حماية من هجمات التكرار
        ->name('verification.verify'); // التحقق من البريد الإلكتروني

    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
        ->middleware('throttle:6,1') // حماية من هجمات التكرار
        ->name('verification.send'); // إرسال إشعار التحقق من البريد الإلكتروني

    Route::get('confirm-password', [ConfirmablePasswordController::class, 'show'])
        ->name('password.confirm'); // عرض نموذج تأكيد كلمة المرور

    Route::post('confirm-password', [ConfirmablePasswordController::class, 'store']); // تأكيد كلمة المرور

    Route::put('password', [PasswordController::class, 'update'])
        ->name('password.update'); // تحديث كلمة المرور

    Route::post('logout', [AuthenticatedSessionController::class, 'destroy'])
        ->name('logout'); // تسجيل الخروج
});
