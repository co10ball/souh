<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisteredUser Controller extends Controller
{
    /**
     * عرض نموذج التسجيل.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('auth.register'); // تأكد من وجود ملف العرض auth/register.blade.php
    }

    /**
     * تخزين بيانات المستخدم الجديد.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        // التحقق من صحة البيانات المدخلة
        $this->validate($request, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'], // تأكيد كلمة المرور
        ]);

        // إنشاء المستخدم الجديد
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password), // تشفير كلمة المرور
        ]);

        // تسجيل الدخول تلقائيًا بعد التسجيل
        auth()->login($user);

        // إعادة التوجيه إلى الصفحة الرئيسية أو أي صفحة أخرى
        return redirect()->route('dashboard'); // تأكد من وجود مسار dashboard
    }
}
