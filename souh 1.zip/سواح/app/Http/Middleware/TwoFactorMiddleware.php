<?php
// app/Http/Middleware/TwoFactorMiddleware.php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class TwoFactorMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (!session('2fa_passed')) {
            return redirect()->route('2fa.show');
        }

        return $next($request);
    }
}