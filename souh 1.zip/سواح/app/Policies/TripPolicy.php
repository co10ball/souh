<?php
// app/Policies/TripPolicy.php

namespace App\Policies;

use App\Models\User;
use App\Models\Trip;

class TripPolicy
{
    /**
     * تحديد ما إذا كان المستخدم يمكنه تحديث الرحلة.
     */
    public function update(User $user, Trip $trip): bool
    {
        return $this->isAdmin($user);
    }

    /**
     * تحديد ما إذا كان المستخدم يمكنه حذف الرحلة.
     */
    public function delete(User $user, Trip $trip): bool
    {
        return $this->isAdmin($user);
    }

    /**
     * التحقق مما إذا كان المستخدم يمتلك دور المشرف.
     */
    protected function isAdmin(User $user): bool
    {
        return optional($user->role)->name === 'admin';
    }
}
