<?php
// app/Notifications/NewTripRequest.php
namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class NewTripRequest extends Notification
{
    use Queueable;

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('New Trip Request')
            ->line('A new trip request has been submitted.')
            ->action('View Requests', url('/admin/requests'))
            ->line('Thank you for using our app!');
    }
public function toArray($notifiable)
    {
        return [
            'message' => 'A new trip request has been submitted.',
            'action_url' => url('/admin/requests'),
        ];
    }
}