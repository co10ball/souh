namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Recommended extends Model
{
    use HasFactory;
    /**
     * الحقول التي يُسمح بتعبئتها جماعيًا.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'trip_id', // معرف الرحلة الموصى بها
        'user_id', // معرف المستخدم الذي أوصى بالرحلة
        'reason',   // سبب التوصية
    ];
    /**
     * العلاقة بين التوصية والرحلة.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function trip(): BelongsTo
    {
        return $