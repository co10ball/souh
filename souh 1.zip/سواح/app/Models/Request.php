     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id', // معرف المستخدم الذي قدم الطلب
        'trip_id', // معرف الرحلة المرتبطة بالطلب
        'status',   // حالة الطلب (مثل: قيد المعالجة، مكتمل، مرفوض)
    ];
    /**
     * العلاقة بين الطلب والمستخدم.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    /**
     * العلاقة بين الطلب والرحلة.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function trip(): BelongsTo
    {
        return $this->belongsTo(Trip::class);
    }
}
