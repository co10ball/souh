        'password',
    ];
    /**
     * الحقول التي يجب إخفاؤها عند التحويل إلى مصفوفة أو JSON.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];
    /**
     * العلاقة بين المستخدم والرسائل.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function messages(): HasMany
    {
        return $this->hasMany(Message::class);
    }
    /**
     * العلاقة بين المستخدم والرحلات.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function trips(): HasMany
    {
        return $this->hasMany(Trip::class);
    }
