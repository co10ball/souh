class Message extends Model
{
    use HasFactory;
    /**
     * الحقول التي يُسمح بتعبئتها جماعيًا.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'content', // نص الرسالة أو محتواها
        'type',    // نوع الرسالة (نص، صورة، فيديو، إلخ)
    ];
    /**
     * العلاقة بين الرسالة والمستخدم الذي أرسلها.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    /**
     * تعريف أنواع الرسائل كثوابت لسهولة الصيانة.
     */
    const TYPE_TEXT = 'text';
    const TYPE_IMAGE = 'image';
    const TYPE_VIDEO = 'video';
}