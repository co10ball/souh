<?php

return [
    'enabled' => true,
    'algorithm' => 'content_based', // content_based, collaborative
    'min_rating' => 3,
    'max_results' => 10,
    'cache_ttl' => 3600,
];