<?php

return [

    // الإصدار الافتراضي للـ API
    'version' => 'v1',

    // معدل الطلبات المسموح به لكل مستخدم في الدقيقة
    'rate_limit' => 60,

    // تمكين التوثيق بواسطة التوكن
    'token_auth' => true,

    // مدة صلاحية التوكن (بالدقائق)
    'token_expiry' => 60 * 24,

    // تمكين Swagger UI لتوثيق API
    'swagger_enabled' => true,

    // صلاحيات الوصول للـ API
    'access_roles' => ['admin', 'moderator', 'user'],

];