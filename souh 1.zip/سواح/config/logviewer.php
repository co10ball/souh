<?php

return [

    'enabled' => true,

    // عدد الأسطر في كل ملف
    'lines_per_page' => 200,

    // الوصول فقط للإداريين
    'access_roles' => ['admin'],

    // مسار ملفات اللوج
    'log_path' => storage_path('logs'),

];