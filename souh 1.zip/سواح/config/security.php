<?php

return [
    '2fa' => [
        'enabled' => true,
        'provider' => 'google_authenticator',
    ],
    'login_throttle' => [
        'enabled' => true,
        'max_attempts' => 5,
        'decay_minutes' => 15,
    ],
];