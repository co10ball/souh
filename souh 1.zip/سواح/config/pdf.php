<?php

return [
    'enabled' => true,
    'default_paper_size' => 'A4',
    'orientation' => 'portrait',
    'margin' => [
        'top' => 10,
        'bottom' => 10,
        'left' => 10,
        'right' => 10,
    ],
    'font' => 'Arial',
    'driver' => env('PDF_DRIVER', 'dompdf'), // dompdf, snappy
];