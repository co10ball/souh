<?php

return [

    'enabled' => true,

    // مسار حفظ النسخ الاحتياطية
    'backup_path' => storage_path('backups'),

    // جدول زمني للنسخ (يومي، أسبوعي، شهري)
    'frequency' => 'daily',

    // عدد النسخ المحفوظة
    'keep_last' => 7,

    // إرسال إشعار بعد كل عملية نسخ احتياطي
    'notify' => true,

];