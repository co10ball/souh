<?php

return [
    'dark_mode' => true,
    'animations' => true,
    'dashboard_charts' => true,
    'theme' => 'modern',
];