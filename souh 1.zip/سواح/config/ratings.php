<?php

return [

    // التقييم من 1 إلى 5
    'max_rating' => 5,

    // تمكين التعليقات النصية بجانب التقييم
    'allow_comments' => true,

    // هل المستخدم يقدر يعدل تقييمه بعد الإرسال؟
    'editable' => true,

    // عدد الحروف المسموح بيها في التعليق
    'max_comment_length' => 500,

    // عرض متوسط التقييم
    'show_average' => true,

];