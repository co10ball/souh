<?php

return [

    // البريد الافتراضي للإرسال منه
    'from_email' => env('MAIL_FROM_ADDRESS', 'noreply@souh.com'),

    // اسم المرسل
    'from_name' => env('MAIL_FROM_NAME', 'Souh Notifications'),

    // إرسال إشعارات البريد
    'email_notifications' => true,

    // إرسال إشعارات في التطبيق
    'in_app_notifications' => true,

    // قوالب البريد
    'templates' => [
        'new_trip' => 'emails.new_trip',
        'new_message' => 'emails.new_message',
    ],

];