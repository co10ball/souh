<?php

return [

    // التوقيت الزمني الافتراضي
    'timezone' => env('APP_TIMEZONE', 'Africa/Cairo'),

    // عدد الأيام التي تظهر في الجدول الزمني
    'default_view_days' => 7,

    // تمكين السحب والإفلات للأحداث
    'drag_and_drop' => true,

    // لون الحدث في الجدول
    'event_color' => '#3B82F6',

    // تنسيق الوقت
    'time_format' => 'H:i',

    // تمكين/تعطيل الأحداث المتكررة
    'recurring_events' => true,

];