<?php

return [

    // عدد العناصر في كل قسم Dashboard
    'stats' => [
        'users' => true,
        'trips' => true,
        'ratings' => true,
        'recommendations' => true,
    ],

    // تمكين الرسوم البيانية
    'charts' => [
        'enabled' => true,
        'types' => ['bar', 'pie', 'line'],
    ],

    // تحديث فوري للأرقام
    'live_update' => true,

    // تحكم في العناصر الظاهرة للمستخدمين حسب الدور
    'roles_visibility' => [
        'admin' => ['all'],
        'moderator' => ['trips', 'ratings'],
        'user' => [],
    ],

];