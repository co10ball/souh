<?php

return [

    // عنوان الموقع الافتراضي
    'default_title' => 'Souh - تقييم الرحلات والأماكن السياحية',

    // وصف الميتا الافتراضي
    'default_description' => 'منصة سواح لمراجعة وتقييم أفضل الرحلات والأماكن السياحية في العالم العربي.',

    // الكلمات المفتاحية الافتراضية
    'default_keywords' => 'رحلات, تقييم, سياحة, سواح, سياحي',

    // تمكين توليد أوتوماتيكي لبيانات SEO للصفحات
    'auto_generate' => true,

    // روابط الشبكات الاجتماعية
    'social' => [
        'facebook' => 'https://facebook.com/souh',
        'twitter' => 'https://twitter.com/souh',
        'instagram' => 'https://instagram.com/souh',
    ],

];