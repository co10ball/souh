<?php

return [
    'enabled' => true,
    'max_messages' => 100,
    'auto_delete_days' => 30,
    'realtime' => true,
    'provider' => env('CHAT_PROVIDER', 'pusher'), // pusher, ably, etc.

    'pusher' => [
        'key' => env('PUSHER_APP_KEY'),
        'secret' => env('PUSHER_APP_SECRET'),
        'app_id' => env('PUSHER_APP_ID'),
        'cluster' => env('PUSHER_APP_CLUSTER'),
    ],
];