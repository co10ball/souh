<?php

return [

    // نوع السجل الافتراضي
    'default' => env('LOG_CHANNEL', 'stack'),

    // مستوى السجلات (debug, info, notice, warning, error, critical, alert, emergency)
    'level' => env('LOG_LEVEL', 'debug'),

    // مسار ملف السجل
    'log_path' => storage_path('logs/souh.log'),

    // تفعيل تسجيل استثناءات مخصصة
    'custom_exceptions' => true,

    // مدة الاحتفاظ بالسجلات (بالأيام)
    'retention_days' => 30,

];