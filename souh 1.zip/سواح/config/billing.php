<?php

return [

    'enabled' => true,

    'currency' => 'USD',

    'plans' => [
        'basic' => [
            'price' => 5,
            'features' => ['limited access', 'basic support'],
        ],
        'pro' => [
            'price' => 15,
            'features' => ['full access', 'priority support', 'analytics'],
        ],
    ],

    'payment_gateway' => [
        'provider' => 'stripe',
        'api_key' => env('STRIPE_API_KEY'),
    ],

];