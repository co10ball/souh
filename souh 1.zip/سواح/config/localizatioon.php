<?php

return [

    // اللغة الافتراضية للموقع
    'default_locale' => env('APP_LOCALE', 'ar'),

    // قائمة اللغات المدعومة
    'supported_locales' => ['ar', 'en', 'fr'],

    // التبديل التلقائي للغة حسب متصفح المستخدم
    'auto_detect' => true,

    // مسار ملفات الترجمة
    'translation_path' => resource_path('lang'),

    // تمكين التخزين المؤقت للترجمات
    'cache_translations' => true,

];