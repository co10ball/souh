<?php

return [

    // 2FA تسجيل دخول مزدوج
    'two_factor_auth' => true,

    // الدردشة المباشرة
    'live_chat' => true,

    // التصدير إلى PDF
    'pdf_export' => true,

    // عرض التقويم
    'calendar_view' => true,

    // رفع سحابي (Cloud Upload)
    'cloud_upload' => true,

    // الوضع الليلي
    'dark_mode' => true,

    // تقييم وتعليقات المستخدمين
    'reviews_enabled' => true,

    // توصيات ذكية بالرحلات
    'smart_recommendations' => true,

    // السحب والإفلات لترتيب العناصر
    'drag_and_drop_sorting' => true,

    // ميزات خاصة (مثلاً: الرحلات المميزة)
    'featured_trips' => true,

    // الانتظار للبريد الإلكتروني (Queue)
    'email_queue' => true,

];