<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Trip;

class TripRequestTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_can_request_trip()
    {
        $user = User::factory()->create();
        $trip = Trip::factory()->create();

        $response = $this->actingAs($user)->post('/trips/'.$trip->id.'/request');

        $response->assertStatus(302); // أو حسب التصميم
        $this->assertDatabaseHas('trip_requests', [
            'user_id' => $user->id,
            'trip_id' => $trip->id
        ]);
    }
}
