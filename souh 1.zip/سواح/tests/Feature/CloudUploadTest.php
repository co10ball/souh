<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CloudUploadTest extends TestCase
{
    use RefreshDatabase;

    public function test_authenticated_user_can_upload_file_to_s3()
    {
        // Arrange: تحضير التخزين المزيف والمستخدم والملف
        Storage::fake('s3');

        $user = User::factory()->create();
        $file = UploadedFile::fake()->image('trip-photo.jpg');

        // Act: تنفيذ الطلب كمستخدم مسجل الدخول
        $response = $this->actingAs($user)->post('/upload', [
            'file' => $file,
        ]);

        // Assert: التحقق من نجاح الاستجابة ووجود الملف
        $response->assertStatus(200); // أو assertRedirect أو assertJson حسب الرد الفعلي

        Storage::disk('s3')->assertExists('uploads/' . $file->hashName());
    }
}
