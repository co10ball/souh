<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Trip;

class TripCreationTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_create_trip()
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $response = $this->actingAs($admin)->post('/trips', [
            'title' => 'Aswan Tour',
            'description' => 'Amazing Nile trip',
            'price' => 500,
            'date' => now()->addDays(10)->format('Y-m-d'),
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('trips', ['title' => 'Aswan Tour']);
    }
}