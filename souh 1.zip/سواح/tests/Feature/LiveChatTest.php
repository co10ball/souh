<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class LiveChatTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_can_send_message_in_chat()
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->post('/chat/send', [
            'message' => 'Hello Support!'
        ]);

        $response->assertStatus(200);
        $this->assertDatabaseHas('messages', [
            'user_id' => $user->id,
            'message' => 'Hello Support!'
        ]);
    }
}
