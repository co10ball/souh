<?php
// tests/Feature/SmartRecommendationTest.php
namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SmartRecommendationTest extends TestCase
{
    use RefreshDatabase;

    public function test_system_shows_recommendations()
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get('/recommendations');

        $response->assertStatus(200);
        $response->assertSee('Recommended for you');
    }
}
