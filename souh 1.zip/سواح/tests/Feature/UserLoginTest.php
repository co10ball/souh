<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;

class UserLoginTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_can_login_successfully()
    {
        // Arrange: إنشاء مستخدم وهمي
        $user = User::factory()->create([
            'email' => 'ahmed@example.com',
            'password' => Hash::make('password123'), // استخدم كلمة مرور أكثر وضوحًا للاختبار
        ]);

        // Act: إرسال طلب تسجيل الدخول
        $response = $this->post('/login', [
            'email' => 'ahmed@example.com',
            'password' => 'password123',
        ]);

        // Assert: التأكد من إعادة التوجيه والنجاح في المصادقة
        $response->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
    }
}
