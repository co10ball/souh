<?php
// tests/Feature/TripTest.php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Trip;

class TripTest extends TestCase
{
    public function test_trip_listing_is_visible()
    {
        Trip::factory()->count(3)->create();

        $response = $this->get('/');

        $response->assertOk(); // بديل لـ assertStatus(200)
        $response->assertSeeText('Trips', false); // Ignore case sensitivity
    }
}
